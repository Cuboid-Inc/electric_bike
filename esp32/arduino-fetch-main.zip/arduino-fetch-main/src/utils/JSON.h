class JSON {
    JSON();
};